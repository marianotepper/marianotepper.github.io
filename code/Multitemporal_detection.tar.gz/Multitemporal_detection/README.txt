Copyright (c) 2015, Mariano Tepper, Alasdair Newson, Pablo Sprechmann, Guillermo Sapiro
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%    CITATION    %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

If you wish to use this code for publications, please cite the
following paper:

Multi-Temporal Foreground Detection in Videos
Mariano Tepper, Alasdair Newson, Pablo Sprechmann, Guillermo Sapiro
International Conference on Image Processing (ICIP), 2015

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% REQUIREMENTS %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

You require Matlab with the ability to compile mex functions to use this code.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This file explains how to use the multi-temporal foreground detection code in this directory. Please read all of the
file before asking any questions, as a lot of information is contained here.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% INSTALLATION %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

To use this software, you need to first compile the code corresponding to the following article :

Fast approximate energy minimization with label costs.
Andrew Delong, Anton Osokin, Hossam Isack and Yuri Boykov
International journal of computer vision 96.1 (2012): 1-27.

This code is contained in the subdirectory named 'multitemporal_reslease', in the zip file named 'gco-v3.0.zip'. The code can also be found at :

http://vision.csd.uwo.ca/code/

To compile this, extract the code in the zip file, and enter into the directory 'gco-v3.0/matlab' with Matlab. Then execute the following command :

>> GCO_BuildLib

If it successfully executes, you should have the following message :

MEX completed successfully.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%    USAGE    %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

An example of the usage of this code may be found in test_multitemporal_detection.m. The main function of the multi-temporal detection is named 'processVideo.m'.

%%%%%%%%%%%%%%    OUTPUT DIRECTORY  %%%%%%%%%%%%%

The output is written to a subdirectory with the same name as the video file. The detection labels are written as image (.png) files, and .mat files. 

%%%%%%%%%%%%%      PARAMETERS    %%%%%%%%%%%%

There are four important parameters to this function :

- sigma : the standard deviation of the noise in the video
- segIncrement : increment between two temporal scales
- segments : number of temporal scales to analyse
- longTermModel : the long-term background model

%%%%%%%%%%%%%    TEMPORAL SCALE  %%%%%%%%%%%%

The second and third parameters (segIncrement and segments) are important for setting the temporal granularity of the multi-temporal foreground detection. In our algorithm, each temporal scale increases by a constant, segIncrement. There are 'segments' number of scales. The unit of these constants is one frame.

So, for example, if segments is set to 5, and segIncrement is set to 4, we would carry out foreground analysis on the following temporal scales :
[4,8,12,16,20],
plus the 'long-term' analysis. These constants should obviously be set according to the temporal scales which the user wishes to analyse.

The algorithm starts analysing the foreground of the video at segIncrement*segments frames, since below this number not enough frames are available for the analysis.

%%%%%%%%%%%%%    LONG TERM MODEL  %%%%%%%%%%%%

The last parameter, 'longTermModel' is the long-term background component. This component corresponds to the background which never moves. For the majority of surveillance applications, it is reasonable to consider that this is known. However, we propose a way of estimating this long-term model in the function 'createLongTermModel', in case the user does not have such a model. If a file named 'longTermModel.mat' does not exist in the folder corresponding to the current video being analysed, then the long-term model is estimated automatically.

%%%%%%%%%%%%%%    EXAMPLE VIDEO  %%%%%%%%%%%%%

We have included an example video from the dataset of the following publication :

Definition and Performance Evaluation of a Robust SVM Based Fall Detection Solution
I. Charfi, J. Miteran, J. Dubois, M. Atri, and R. Tourki
International Conference on Signal Image Technology and Internet Based Systems

The analysis of this video is carried out by exectuing test_multitemporal_detection.m.

A good long-term model of this video is provided with the code.
