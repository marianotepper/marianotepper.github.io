
close all;
clear all;
restoredefaultpath;

addpath(genpath('multitemporal_release'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  PARAMETERS  %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r = 3;      %maximum rank of multi-temporal low-rank background models
sigma = 0.05;   %variance of noise in the video
timeSubsample = 1;  %if we wish to subsample the video temporally
segIncrement = 20;  %constant increment (in frames) between two temporal scales
segments = 5;   %number of different temporal scales

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  INPUT FILE  %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fileName = 'Falling_person_1.avi';%
vidIn = VideoReader(fileName);

outputFolder = fileName(1:end-4);
startPoint = 1;
nbFrames = get(vidIn,'NumberOfFrames');
videoFrames = min(round((nbFrames-startPoint+1)/timeSubsample),nbFrames/timeSubsample);

%remove result files which already exist
if (exist([outputFolder '/longTermModel.mat'],'file'))
    delete([outputFolder '/*.png']);
    delete([outputFolder '/labels*.mat']);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  CREATE A VIDEO READING OBJECT  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%optional logical mask which indicates where the estimation should be
%carried out in the image
mask = 255*ones(floor(get(vidIn,'Height')), floor(get(vidIn,'Width')));
mask = mask == 255;
%video reader object
VR = videoReader_AVI(fileName, timeSubsample, startPoint, videoFrames,mask);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  CREATE LONG TERM MODEL  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Building/retrieving long term model:');

if (exist([outputFolder '/longTermModel.mat'],'file'))
    load([outputFolder '/longTermModel.mat'], 'longTermModel');
else
    longTermModel = createLongTermModel(VR, r, sigma);
    if ~isdir(outputFolder)
        mkdir(outputFolder);
    end
    save([outputFolder '/longTermModel.mat'], 'longTermModel');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%  CARRY OUT MULTITEMPORAL DETECTION  %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Multi-temporal RPCA:');
processVideo(VR, r, sigma, segIncrement, segments, longTermModel, outputFolder);