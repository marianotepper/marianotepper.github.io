function labeling = smoothTemporalLabels(temporalLabels, nLabels, weight)

imSize = size(temporalLabels);
N = prod(imSize);

neighbors = zeros(N*4, 2);

idx = 1;
for j = 1:imSize(2)
    for i = 1:imSize(1)

        current = i + (j-1) * imSize(1);
        if i > 1
            neigh = (i-1) + (j-1) * imSize(1);
            neighbors(idx, 1) = current;
            neighbors(idx, 2) = neigh;
            idx = idx + 1;
        end
        if i < imSize(1)
            neigh = (i+1) + (j-1) * imSize(1);
            neighbors(idx, 1) = current;
            neighbors(idx, 2) = neigh;
            idx = idx + 1;
        end
        if j > 1
            neigh = (i) + (j-2) * imSize(1);
            neighbors(idx, 1) = current;
            neighbors(idx, 2) = neigh;
            idx = idx + 1;
        end
        if j < imSize(2)
            neigh = (i) + (j) * imSize(1);
            neighbors(idx, 1) = current;
            neighbors(idx, 2) = neigh;
            idx = idx + 1;
        end
    end
end
neighbors(idx:end, :) = [];
neighbors = sparse(neighbors(:, 1), neighbors(:, 2), 1, N, N);

dataCost = int32(zeros(nLabels, N));
for k = 1:nLabels
    dataCost(k, :) = weight * (temporalLabels(:) ~= k-1);
end

%%
% tic;
h = GCO_Create(N, nLabels);             % Create new object with NumSites=4, NumLabels=3
GCO_SetDataCost(h, dataCost);
GCO_SetNeighbors(h, neighbors);
GCO_Expansion(h);                % Compute optimal labeling via alpha-expansion 
labeling = GCO_GetLabeling(h);
GCO_Delete(h);                   % Delete the GCoptimization object when finished
% toc;

labeling = reshape(labeling-1, imSize(1), imSize(2));

% figure,
% subplot(121); imagesc(temporalLabels); axis image;
% title('Before multi-temporal blending');
% subplot(122); imagesc(reshape(labeling-1, imSize(1), imSize(2))); axis image;
% title('After multi-temporal blending');


end

