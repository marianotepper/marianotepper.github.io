function [f,df,dalpha] = shrinkage(t, alpha)

tt = abs(t) - alpha;
f  = sign(t) .* max( 0, tt );
if nargout > 1,
    df     = double( tt >= 0);
    dalpha = -df.*sign(t);
end