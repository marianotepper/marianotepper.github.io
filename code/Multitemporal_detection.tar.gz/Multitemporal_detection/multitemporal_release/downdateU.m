function [U, A, B] = downdateU(x_t, s_t, o_t, A, B, lambda_ast)

A = A - s_t * s_t';
B = B - (x_t - o_t) * s_t';    

U = B / (A + lambda_ast * eye(size(A)));

