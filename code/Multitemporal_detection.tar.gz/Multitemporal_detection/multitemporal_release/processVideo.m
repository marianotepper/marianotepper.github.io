%this function detects foreground at multiple temporal scales
%in a video.
%input:
%1/ videoReader : the video objectg reader
%2/ r : maximum rank of the low-rank background approximations
%3/ sigma : standard deviation of the noise in the video
%4/ segIncrement : temporal increment (in frames) between two successive temporal scales
%5/ segments : number of different scales to be analysed
%6/ longTermModel : the long-term low-rank background component of the
%video. This should correspond to the background which does not change at
%all in the video
%7/ resultDirName : the name of the directory where the results should be
%put
function processVideo(videoReader, r, sigma, segIncrement, segments, longTermModel, resultDirName)

if ~isdir(resultDirName)
    mkdir(resultDirName);
end

lambda = sigma * sqrt(2);
nFrames = segments * segIncrement;

cellU = {};
cellS = {};
cellO = {};
cellA = {};
cellB = {};
cellLambda_ast = {};

%iterate over the number of frames in the video
for i = 0:videoReader.size-1

    imgOrig = videoReader.getFrame(i);
    imSize = size(imgOrig);
    img = imgOrig(videoReader.mask);
    [maskRows, maskCols] = find(videoReader.mask(:,:,1));
    
    tStart = tic;
    tStartDetection= tic;
    
    if i < nFrames
        multi = floor(i / segIncrement);
        remi = rem(i, segIncrement);

        if remi == 0
            initialVideo = zeros(numel(img), r);
        end
        if remi < r
            initialVideo(:,remi+1) = img;
        end
        if remi+1 == r %&& numel(cellU) <= 5

            [Us,Ss,~] = svds(initialVideo, r);
            U = Us*sqrt(Ss);
            S = [];
            O = [];
            A = [];
            B = [];

            framesInSegment = segIncrement * (segments - multi);
            lambda_ast = sigma * sqrt(2 * framesInSegment);

            for k = 1:r
                [s_k, o_k, ~] = updateSO(initialVideo(:,k), U, lambda_ast, lambda);
                [U, A, B] = updateU(initialVideo(:,k), s_k, o_k, A, B, lambda_ast);
                S = [S s_k];
                O = [O sparse(o_k)];
            end

            cellU{multi+1} = U;
            cellS{multi+1} = S;
            cellO{multi+1} = O;
            cellA{multi+1} = A;
            cellB{multi+1} = B;
            cellLambda_ast{multi+1} = lambda_ast;
        end
    end

    % remove old data point
    if i >= nFrames
        for k = 1:segments            
            idxToRemove = i - (segments-k+1) * segIncrement;
            
            imgToRemove = videoReader.getFrame(idxToRemove);
            imgToRemove = imgToRemove(videoReader.mask);
            
            S = cellS{k};
            O = cellO{k};
            A = cellA{k};
            B = cellB{k};

            [U, A, B] = downdateU(imgToRemove, S(:, 1), O(:, 1), A, B, cellLambda_ast{k});
            S(:, 1) = [];
            O(:, 1) = [];

            cellU{k} = U;
            cellS{k} = S;
            cellO{k} = O;
            cellA{k} = A;
            cellB{k} = B;

        end    
    end
    
    % add new data point
    for k = 1:numel(cellU)
        if i < nFrames && k == multi+1 && remi < r
            continue;
        end
        
        U = cellU{k};
        S = cellS{k};
        O = cellO{k};
        A = cellA{k};
        B = cellB{k};

        [s_k, o_k, ~] = updateSO(img, U, cellLambda_ast{k}, lambda);
        [U, A, B] = updateU(img, s_k, o_k, A, B, cellLambda_ast{k});
        S = [S s_k];
        O = [O sparse(o_k)];

        cellU{k} = U;
        cellS{k} = S;
        cellO{k} = O;
        cellA{k} = A;
        cellB{k} = B;

    end
    
    % encode current frame
    if i >= nFrames
        
        [~,o_longTerm,~] = updateSO(img, longTermModel.U, longTermModel.lambda_ast, longTermModel.lambda);
        
        %change to convert colour to gray scale
        if (numel(imSize) == 3)
            o_longTerm = reshape(o_longTerm,imSize);
            o_longTerm = max(o_longTerm,[],3);
            o_longTerm = o_longTerm(:);
        end
        o_longTerm = abs(o_longTerm) > 0;
        
        sparseComponents = zeros(imSize(1), imSize(2), segments+1);
        
        sparseComponents(:,:,1) = full(sparse(maskRows, maskCols, o_longTerm, imSize(1), imSize(2)));
                
        for k = 1:segments
            [s_k, o_k,~] = updateSO(img, cellU{k}, cellLambda_ast{k}, lambda);

            %change to convert colour to gray scale
            if (numel(imSize) == 3)
                o_k = reshape(o_k,imSize);
                o_k = max(o_k,[],3);
                o_k = o_k(:);
            end
            
            o_k = abs(o_k) > 0 & o_longTerm;
            
            sparseComponents(:,:,k+1) = full(sparse(maskRows, maskCols, o_k, imSize(1), imSize(2))) * (k+1);
        end
        
        temporalLabels = max(sparseComponents, [], 3);
        
        tElapsedDetection = toc(tStartDetection)

        temporalLabels_smooth = smoothTemporalLabels(temporalLabels, segments+2, 1.5);
        
        cmap = lbmap(segments+1, 'BlueRed');
        
        alpha_data2 = zeros(size(temporalLabels_smooth)) + .5 * (temporalLabels_smooth > 0);
        im2 = ind2rgb(double(temporalLabels_smooth) - 1. * (temporalLabels_smooth > 0), cmap);
        write_transparent_image(imgOrig,im2,alpha_data2,[resultDirName '/' resultDirName '_smoothed_result'],i)
        
        imwrite(ind2rgb(temporalLabels, cmap), [resultDirName '/labels_color_' sprintf('%05d', i) '.png']);
        imwrite(ind2rgb(temporalLabels_smooth, cmap), [resultDirName '/labels_smooth_color_' sprintf('%05d', i) '.png']);
        save([resultDirName '/labels_' sprintf('%05d', i) '.mat'], 'temporalLabels', 'temporalLabels_smooth');
    end
        
    tElapsed = toc(tStart);
    disp(['i=' int2str(i) '; ' num2str(tElapsed)]);
    
    if (exist('stop_and_debug.txt','file'))
        keyboard;
    end
end

end

