function longTermModel = createLongTermModel(videoReader, r, sigma)

    lambda = sigma * sqrt(2);
    lambda_ast = sigma * sqrt(2 * videoReader.size);

    for i = 0:r-1
        img = videoReader.getFrame(i);  %get frame from start time, potentially subsampled
        img = img(videoReader.mask); %only get image information inside a certain mask

        if i == 0   %if this the first frame, create the matrix into which the
            %video will be put
           initialVideo = zeros(numel(img), r);
        end
        initialVideo(:,i+1) = img;
    end

    [U, S,~] = svds(initialVideo, r);   %find the r largest singular values and left vectors
    U = U * sqrt(S);

    A = [];
    B = [];

    avgTime = 0;

    for i = r:videoReader.size-1    %build long term background using r to sizeVideo frames

        img = videoReader.getFrame(i);
        img = img(videoReader.mask);

        tStart = tic;

        %update solution to minimisation problem
        %update S and O
        [s_i, o_i, ~] = updateSO(img, U, lambda_ast, lambda);
        %update U
        [U, A, B] = updateU(img, s_i, o_i, A, B, lambda_ast);

        tElapsed = toc(tStart);
        avgTime = avgTime + tElapsed;
        %display purposes
        if mod(i, floor(videoReader.size / 10)) == 0
            disp(['i=' int2str(i) ' / ' int2str(videoReader.size) '; ' num2str(tElapsed)]);
        end
    end

    avgTime = avgTime / (videoReader.size - r);

    disp(['avg time ' num2str(avgTime)]);

    %set the lambda and lambda_* parameters
    longTermModel.U = U;
    longTermModel.lambda = lambda;
    longTermModel.lambda_ast = lambda_ast;


end

