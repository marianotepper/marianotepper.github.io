function [s,o,iter] = updateSO(x, U, lambda_ast, lambda, maxiter, minchange)

if nargin < 5
    maxiter = 1e4;
end

if nargin < 6
    minchange = 1e-3;
end

prox = @(m)(shrinkage(m, lambda));

q = size(U,2);

s = rand(q,1);
o = zeros(size(x));

L = (U'*U+lambda_ast*eye(q))\U';

for iter = 1:maxiter
    
    sn = s;
    s = L*(x-o);
    
    on = o;
    o = prox(x-U*s);
    
    err = sum( [sum((s-sn).^2) sum((o-on).^2)]);
    if iter >= 5 && err < minchange
%         disp(iter);
        break;
    end
end


