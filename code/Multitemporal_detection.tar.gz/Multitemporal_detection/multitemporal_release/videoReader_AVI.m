classdef videoReader_AVI
    %VIDEOREADER Summary of this class goes here
    %   Detailed explanation goes here

    properties
        toGrayScale = true;
    end

    properties (SetAccess = private, GetAccess = private)
        objVR
        timeDownsample
    end

    properties (SetAccess = private)
        fps
        start
        size 
        mask
    end
    

    methods
        function VR = videoReader_AVI(filename, timeDownsample, start, size, mask)
            
            VR.objVR = VideoReader(filename);
            VR.timeDownsample = timeDownsample;
            
            VR.fps = VR.objVR.FrameRate / timeDownsample;
            VR.start = start;
            if VR.objVR.NumberOfFrames < size * timeDownsample
                error(['Video only has ' num2str(VR.objVR.NumberOfFrames) ' frames']);
            end
            if isempty(size)
                VR.size = VR.objVR.NumberOfFrames;
            else
                VR.size = size;
            end
            if nargin == 5
                VR.mask = mask;
            else
                VR.mask = true(VR.objVR.Height, VR.objVR.Width);
            end
        end
        
        function img = getFrame(VR, idx)
            
            img = read(VR.objVR, round(VR.start + idx * VR.timeDownsample));
            if VR.toGrayScale
                img = rgb2gray(img);
            end
            img = im2double(img);
        end

        function img = getRawFrame(VR, idx)
            
            img = read(VR.objVR, round(VR.start + idx * VR.timeDownsample));
        end
        
        function timeDownSampleOut = getTimeDownSample(VR)
            
            timeDownSampleOut = VR.timeDownsample;
        end
        
    end
    
end

