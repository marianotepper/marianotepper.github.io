function h = overlay(I1, I2, alpha)

rows_padding = (size(I1, 1) - size(I2, 1)) / 2;
cols_padding = (size(I1, 2) - size(I2, 2)) / 2;
    
if rows_padding > 0 || cols_padding > 0
    I2 = padarray(I2, [rows_padding, cols_padding]);
end

imshow(I1, 'Border', 'tight');
hold on
h = imshow(I2, 'Border', 'tight'); % Save the handle; we'll need it later
hold off

set(h, 'AlphaData', alpha);