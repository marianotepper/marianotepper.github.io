function [U, A, B] = updateU(x_t, s_t, o_t, A, B, lambda_ast)

if isempty(A) && isempty(B)
    A = s_t * s_t';
    B = (x_t - o_t) * s_t';
else
    A = A + s_t * s_t';
    B = B + (x_t - o_t) * s_t';    
end

U = B / (A + lambda_ast * eye(size(A)));

