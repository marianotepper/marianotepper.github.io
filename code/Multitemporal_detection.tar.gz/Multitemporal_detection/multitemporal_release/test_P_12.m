fileName = '../P_12 MOS-P-Ms 010513 000000 S 000087.mp4';
outputFolder = fileName(1:end-4);
startPoint = 3600;
videoFrames = 400;

r = 3;
sigma = 0.05;

segIncrement = 30;
segments = 10;

img = imread([outputFolder ' mask.png']);
% img = impyramid(img, 'reduce');
mask = zeros(size(img,1), size(img,2));
mask(img(:,:,1) > 10) = 127;
mask(img(:,:,2) > 10) = 255;
mask = mask == 255;

VR = videoReader_AVI(fileName, 2, startPoint, videoFrames, mask);

%%


% disp('Building long term model:');
% longTermModel = longTermModel(VR, r, sigma);
% 
% if ~isdir(outputFolder)
%     mkdir(outputFolder);
% end
% save([outputFolder '/longTermModel.mat'], 'longTermModel');
load([outputFolder '/longTermModel.mat'], 'longTermModel');

addpath('./gco-v3.0/matlab/');

disp('Multi-temporal RPCA:');
processVideo(VR, r, sigma, segIncrement, segments, longTermModel, outputFolder, true);
