
function[] = write_transparent_image(imgA,imgB,alphaData,fileName,frameNb)

    if (ndims(imgA)==3)   %change to greyscale image
        imgA = rgb2gray(imgA);
    end
    imgOut = repmat(imgA,[1 1 3]);
    alphaData = repmat(alphaData,[1 1 3]);
    
    imgOut(alphaData>0) = imgB(alphaData>0);%;%imgOut(alphaData>0).*imgB(alphaData>0);%
    imwrite(imgOut,[fileName '_frame_' sprintf('%05d', frameNb) '.png']);


end