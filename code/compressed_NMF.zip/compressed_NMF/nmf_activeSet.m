% Randomly Compressed Nonnegative Matrix Factorization by Alternating
% Nonnegativity Constrained Least Squares using the Active Set method
%
% References:
%  [1] If you use this software with compression, please cite:
%          Mariano Tepper and Guillermo Sapiro, Compressed Nonnegative
%          Matrix Factorization is Fast and Accurate, 2015.
%  [2] If you use this software without compression, please cite:
%          Hyunsoo Kim and Haesun Park, Nonnegative Matrix Factorization
%          Based on Alternating Nonnegativity Constrained Least Squares
%          and Active Set Method, SIAM Journal on Matrix Analysis and
%          Applications, 2008, 30, 713-730
%
% Base code (without compression) written by Jingu Kim
%
% Code significantly simplified by Mariano Tepper
% Compression option written by Mariano Tepper
% Copyright (c) 2015 by Mariano Tepper, Duke University
% 
% This file is under the BSD 3-Clause License,
% which can be found in the LICENSE file in the root directory, or at
% http://opensource.org/licenses/BSD-3-Clause
%
%
% <Inputs>
%        A : Input data matrix (m x n)
%        k : Target low-rank
%
%        Optional arguments can be set by providing name-value pairs:
%        MAX_ITER : Maximum number of iterations. Default is 100.
%        MIN_ITER : Minimum number of iterations. Default is 20.
%        MAX_TIME : Maximum amount of time in seconds. Default is 100,000.
%        W_INIT : (m x k) initial value for W.
%        H_INIT : (k x n) initial value for H.
%        TOL : Stopping tolerance. Default is 1e-3. If you want to obtain
%        a more accurate solution, decrease TOL and increase MAX_ITER at
%        the same time.
%        COMP_LEVEL : compression level, should be greater than k
% <Outputs>
%        W : Obtained basis matrix (m x k)
%        H : Obtained coefficients matrix (k x n)
%        iter : Number of iterations
% <Usage Examples>
%        nmf(A, 10);
%        nmf(A, 10, 'compressed', true);
%        nmf(A, 10, 'compressed', true, 'comp_level', 25);
%
function [W, H, iter] = nmf_activeSet(A, k, varargin)
    [m,n] = size(A); ST_RULE = 1;

    % Default configuration
    par.m = m;
    par.n = n;
    par.max_iter = 100;
    par.min_iter = 20;
    par.max_time = 1e6;
    par.tol = 1e-3;
    par.compressed = false;
    par.comp_level = 20;
    
    W = rand(m,k);
    H = rand(k,n);

    % Read optional parameters
    if (rem(length(varargin),2)==1)
        error('Optional parameters should always go by pairs');
    else
        for i=1:2:(length(varargin)-1)
            switch upper(varargin{i})
                case 'MAX_ITER',            par.max_iter = varargin{i+1};
                case 'MIN_ITER',            par.min_iter = varargin{i+1};
                case 'MAX_TIME',            par.max_time = varargin{i+1};
                case 'W_INIT',              W = varargin{i+1};
                case 'H_INIT',              H = varargin{i+1};
                case 'TOL',                 par.tol = varargin{i+1};
                case 'COMPRESSED',			par.compressed = varargin{i+1};
                case 'COMP_LEVEL',          par.comp_level = varargin{i+1};
                otherwise
                    error(['Unrecognized option: ',varargin{i}]);
            end
        end
    end
        
    if par.compressed
        l = min(max(par.comp_level, k + 10), n);
        OmegaL = randn(n,l);
        B = A * OmegaL;
        for j = 1:4
            B = A * (A' * B);
        end
        [L,~] = qr(B, 0);
        L = L';

        OmegaR = randn(l, m);
        B = OmegaR * A;
        for j = 1:4
            B = (B * A') * A;
        end
        [R,~] = qr(B', 0);

        A_L = L * A;            
        A_R = A * R;
    end
    
    tStart = cputime; tTotal = 0;
    initSC = getInitCriterion(ST_RULE,A,W,H);
    SCconv = 0; SC_COUNT = 3;
	    
    for iter=1:par.max_iter
        
        if par.compressed
            W_L = L * W;
            [H,~,~] = nnlsm_activeset(W_L, A_L, 1, 0, H);
            H_R = H * R;
            [W,gradW,~] = nnlsm_activeset(H_R', A_R', 1, 0, W');
        else
            [H,~,~] = nnlsm_activeset(W, A, 1, 0, H);
            [W,gradW,~] = nnlsm_activeset(H', A', 1, 0, W');
        end    
                
        W=W';
        gradW=gradW';
        gradH = (W'*W)*H - W'*A;
        
        if (iter > par.min_iter)
            SC = getStopCriterion(ST_RULE,A,W,H,gradW,gradH);
            if (cputime-tStart)>par.max_time
                break;
            elseif (SC/initSC <= par.tol)
                SCconv = SCconv + 1;
                if (SCconv >= SC_COUNT), break; end
            else
                SCconv = 0;
            end
        end
    end
    
    if issparse(A)
        W = sparse(W);
        H = sparse(H);
    end
end

%-------------------------------------------------------------------------------
function retVal = getInitCriterion(stopRule,A,W,H,gradW,gradH)
% STOPPING_RULE : 1 - Normalized proj. gradient
%                 2 - Proj. gradient
%                 3 - Delta by H. Kim
%                 0 - None (want to stop by MAX_ITER or MAX_TIME)
    if nargin~=9
        [gradW,gradH] = getGradient(A,W,H);
    end
    [m,~]=size(W); [k,n]=size(H); numAll=(m*k)+(k*n);
    switch stopRule
        case 1
            retVal = norm([gradW; gradH'],'fro')/numAll;
        case 2
            retVal = norm([gradW; gradH'],'fro');
        case 3
            retVal = getStopCriterion(3,A,W,H,gradW,gradH);
        case 0
            retVal = 1;
    end
end
%-------------------------------------------------------------------------------
function retVal = getStopCriterion(stopRule,A,W,H,gradW,gradH)
% STOPPING_RULE : 1 - Normalized proj. gradient
%                 2 - Proj. gradient
%                 3 - Delta by H. Kim
%                 0 - None (want to stop by MAX_ITER or MAX_TIME)
    if nargin~=9
        [gradW,gradH] = getGradient(A,W,H);
    end

    switch stopRule
        case 1
            pGrad = [gradW(gradW<0|W>0); gradH(gradH<0|H>0)];
            pGradNorm = norm(pGrad);
            retVal = pGradNorm/length(pGrad);
        case 2
            pGrad = [gradW(gradW<0|W>0); gradH(gradH<0|H>0)];
            retVal = norm(pGrad);
        case 3
            resmat=min(H,gradH); resvec=resmat(:);
            resmat=min(W,gradW); resvec=[resvec; resmat(:)]; 
            deltao=norm(resvec,1); %L1-norm
            num_notconv=length(find(abs(resvec)>0));
            retVal=deltao/num_notconv;
        case 0
            retVal = 1e100;
    end
end
%-------------------------------------------------------------------------------
function [gradW,gradH] = getGradient(A,W,H)
    gradW = W*(H*H') - A*H';
    gradH = (W'*W)*H - W'*A;
end
