% Randomly Compressed Nonnegative Matrix Factorization using ADMM
%
% If you use this software, please cite:
%    Mariano Tepper and Guillermo Sapiro, Compressed Nonnegative
%    Matrix Factorization is Fast and Accurate, 2015.
%
% Copyright 2015 by Mariano Tepper, Duke University
% 
% This file is under the BSD 3-Clause License,
% which can be found in the LICENSE file in the root directory, or at
% http://opensource.org/licenses/BSD-3-Clause%
%
% <Inputs>
%        A : Input data matrix (m x n)
%        q : Target low-rank
%        lambda : Lagrange multiplier
%        phi : Lagrange multiplier
%        nIter : maximum number of iterations, default is 1e4
%        compressionLevel : compression level, should be greater than q
%
% <Outputs>
%        U : Obtained basis matrix (m x k)
%        V : Obtained coefficients matrix (k x n)
%        err : Relative reconstruction error in each iteration
%
function [U, V, err] = nmf_admm_struct_comp(A, q, lambda, phi, nIter, compressionLevel)

if nargin < 5
    nIter = 1e4;
end
if nargin < 6
    compressionLevel = 20;
end

[m, n] = size(A);
l = min(n, max(compressionLevel, q + 10));

OmegaL = randn(n,l);
H = A * OmegaL;
for j = 1:4
    H = A * (A' * H);
end
[L,~] = qr(H, 0);
LA = L' * A;

OmegaR = randn(l, l);
H = OmegaR * LA;
for j = 1:4
    H = (H * LA') * LA;
end
[R,~] = qr(H', 0);
R = R';

M = LA * R';

U = abs(rand(m, q));
V = abs(rand(q, n));
Y = V * R';

lambdaMat = zeros(m, q);
phiMat = zeros(q, n);
identity_q = eye(q);

err = zeros(nIter, 1);
for i=1:nIter
    temp = L' * (lambda * U - lambdaMat);
    X = (M * Y' + temp) / (Y * Y' + lambda * identity_q);
    
    temp = (phi * V - phiMat) * R';    
    Y = (X' * X + phi * identity_q) \ (X' * M + temp);
    
    U = max(L * X + lambdaMat / lambda, 0);
    V = max(Y * R + phiMat / phi, 0);

    zerosUV = (sum(U>0) == 0) & (sum(V>0, 2)' == 0);
    if any(zerosUV)
        zerosUV = -1 * zerosUV + 1 * (zerosUV == 0);
        X = bsxfun(@times, X, zerosUV);
        Y = bsxfun(@times, Y, zerosUV');
        lambdaMat = bsxfun(@times, lambdaMat, zerosUV);
        phiMat = bsxfun(@times, phiMat, zerosUV');
        U = max(L * X + lambdaMat / lambda, 0);
        V = max(Y * R + phiMat / phi, 0);        
    end

    lambdaMat = lambdaMat + lambda * (L * X - U);
    phiMat = phiMat + phi * (Y * R - V);

    err(i) = log10(norm(M - X * Y, 'fro'));

    if i > 1e2 && (err(i) < -5 || abs(err(i) - err(i-1)) <= 1e-5)
        err(i+1:end) = [];
        break;
    end
end

if issparse(A)
    U = sparse(U);
    V = sparse(V);
end
