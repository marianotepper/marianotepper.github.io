% Nonnegative Matrix Factorization using multiplicative updates
%
% If you use this software, please cite:
%  [1] C. Ding, T. Li, and M. I. Jordan, Convex and seminonnegative matrix
%      factorizations, IEEE Transactions on Pattern Analysis and Machine
%      Intelligence, 32(1), pp. 45?55, 2010.
%  [2] Mariano Tepper and Guillermo Sapiro, Compressed Nonnegative
%      Matrix Factorization is Fast and Accurate, 2015.
%
% Copyright 2015 by Mariano Tepper, Duke University
% 
% This file is under the BSD 3-Clause License,
% which can be found in the LICENSE file in the root directory, or at
% http://opensource.org/licenses/BSD-3-Clause%
%
% <Inputs>
%        A : Input data matrix (m x n)
%        q : Target low-rank
%        n_iter : maximum number of iterations, default is 1e4
%
% <Outputs>
%        U : Obtained basis matrix (m x k)
%        V : Obtained coefficients matrix (k x n)
%        err : Relative reconstruction error in each iteration
%
function [X, Y, err] = nmf_multiplicative(M, q, nIter)

if nargin < 3
    nIter = 1e4;
end

[m,n] = size(M);
X=rand(m,q);
Y=rand(q,n);

if issparse(M)
    Y = sparse(Y);
    X = sparse(X);
end

err = zeros(nIter, 1);
for i=1:nIter
    
    X = X .* ((M * Y') ./ (X * (Y * Y') + eps));
    Y = Y .* ((X' * M) ./ ((X' * X) * Y + eps));
    
    err(i) = log10(norm(M - X*Y, 'fro'));

    if i > 1e1 && (err(i) < -5 || abs(err(i) - err(i-1)) <= 1e-5)
        err(i+1:end) = [];
        break;
    end
end

end