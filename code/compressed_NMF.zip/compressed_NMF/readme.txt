This folder contains the code corresponding to the paper:
    Mariano Tepper and Guillermo Sapiro, Compressed Nonnegative
    Matrix Factorization is Fast and Accurate, 2015.
If you use this software, please cite the paper.

Copyright 2015 by Mariano Tepper, Duke University

The files contained in this folder are under the BSD 3-Clause License,
which can be found in the LICENSE file in the root directory, or at
http://opensource.org/licenses/BSD-3-Clause
