m = 300;
n = 200;
q = 10;
X = rand(m, q);
Y = rand(q, n);

A = X * Y;

%% NMF using ADMM
[U_1, V_1, ~] = nmf_admm(A, q, 1, 1, 1e4);
%% NMF using multiplicative updates
[U_2, V_2, ~] = nmf_multiplicative(A, q, 1e4);
%% NMF using active set
[U_3, V_3, ~] = nmf_activeSet(A, q);
%% Compressed NMF using multiplicative updates
[U_4, V_4, ~] = nmf_mul_struct_comp(A, q, 1e4, 20);
%% Compressed NMF using ADMM
[U_5, V_5, ~] = nmf_admm_struct_comp(A, q, 1, 1, 1e4, 20);
%% NMF using ADMM using active set
[U_6, V_6, ~] = nmf_activeSet(A, q, 'compressed', true, 'comp_level', 20);