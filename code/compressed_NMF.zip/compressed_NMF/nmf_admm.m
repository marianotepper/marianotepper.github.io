% Nonnegative Matrix Factorization using ADMM
%
% Reference:
%     Yangyang Xu, Wotao Yin, Zaiwen Wen, and Yin Zhang,
%     An alternating direction algorithm for matrix completion with
%     nonnegative factors, Frontiers of Mathematics in China, 7(2),
%     pp. 365-384, 2012.
%
% Copyright 2015 by Mariano Tepper, Duke University
% 
% This file is under the BSD 3-Clause License,
% which can be found in the LICENSE file in the root directory, or at
% http://opensource.org/licenses/BSD-3-Clause%
%
% <Inputs>
%        A : Input data matrix (m x n)
%        q : Target low-rank
%        lambda : Lagrange multiplier
%        phi : Lagrange multiplier
%        n_iter : maximum number of iterations, default is 1e4
%
% <Outputs>
%        U : Obtained basis matrix (m x k)
%        V : Obtained coefficients matrix (k x n)
%        err : Relative reconstruction error in each iteration
%
function [U, V, err] = nmf_admm(M, q, lambda, phi, nIter)

if nargin < 5
    nIter = 1e4;
end

[m, n] = size(M);

[X, S, Y] = svds(M, q);
X = abs(X * sqrt(S));
Y = abs(sqrt(S) * Y');

if issparse(M)
    Y = sparse(Y);
    U = sparse(X);
    V = Y;
    lambdaMat = sparse(m, q, 0);
    phiMat = sparse(q, n, 0);
    identity_q = sparse(1:q, 1:q, 1);
else
    U = X;
    V = Y;
    lambdaMat = zeros(m, q);
    phiMat = zeros(q, n);
    identity_q = eye(q, q);
end

normM = log10(norm(M, 'fro'));

err = zeros(nIter, 1);
for i=1:nIter
    
    X = (M * Y' + lambda * U - lambdaMat) / (Y * Y' + lambda * identity_q);
    X(abs(X)<eps) = 0;
    Y = (X' * X + phi * identity_q) \ (X' * M + phi * V - phiMat);
    Y(abs(Y)<eps) = 0;
    U = max(X + lambdaMat / lambda, 0);
    V = max(Y + phiMat / phi, 0);
    
    zerosUV = (sum(U>=0) == 0) & (sum(V>=0, 2)' == 0);
    if any(zerosUV)
        zerosUV = -1 * zerosUV + 1 * (zerosUV == 0);
        X = bsxfun(@times, X, zerosUV);
        Y = bsxfun(@times, Y, zerosUV');
        lambdaMat = bsxfun(@times, lambdaMat, zerosUV);
        phiMat = bsxfun(@times, phiMat, zerosUV');
        U = max(X + lambdaMat / lambda, 0);
        V = max(Y + phiMat / phi, 0);
    end
    
    lambdaMat = lambdaMat + lambda * (X - U);
    phiMat = phiMat + phi * (Y - V);
    
    err(i) = log10(norm(M - X*Y, 'fro')) - normM;

    if i > 1e1 && (err(i) < -5 || abs(err(i) - err(i-1)) <= 1e-5)
        err(i+1:end) = [];
        break;
    end
end

end