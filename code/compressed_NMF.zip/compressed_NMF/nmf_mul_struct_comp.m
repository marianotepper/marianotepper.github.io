% Randomly Compressed Nonnegative Matrix Factorization using multiplicative
% updates
%
% If you use this software, please cite:
%     Mariano Tepper and Guillermo Sapiro, Compressed Nonnegative
%     Matrix Factorization is Fast and Accurate, 2015.
%
% Copyright 2015 by Mariano Tepper, Duke University
% 
% This file is under the BSD 3-Clause License,
% which can be found in the LICENSE file in the root directory, or at
% http://opensource.org/licenses/BSD-3-Clause%
%
% <Inputs>
%        A : Input data matrix (m x n)
%        q : Target low-rank
%        nIter : maximum number of iterations, default is 1e4
%        compressionLevel : compression level, should be greater than q
%
% <Outputs>
%        U : Obtained basis matrix (m x k)
%        V : Obtained coefficients matrix (k x n)
%        err : Relative reconstruction error in each iteration
%
function [U, V, err] = nmf_mul_struct_comp(A, q, nIter, compressionLevel)

if nargin < 3
    nIter = 1e4;
end
if nargin < 4
    compressionLevel = 20;
end

[m, n] = size(A);
l = min(n, max(compressionLevel, q + 10));

OmegaL = randn(n,l);
H = A * OmegaL;
for j = 1:4
    H = A * (A' * H);
end
[L,~] = qr(H, 0);
L = L';

OmegaR = randn(l, m);
H = OmegaR * A;
for j = 1:4
    H = (H * A') * A;
end
[R,~] = qr(H', 0);

M = L * A * R;
A_L = L * A;
A_R = A * R;

U = abs(rand(m, q));
V = abs(rand(q, n));

U_comp = L * U;

err = zeros(nIter, 1);
for i=1:nIter

    num = proj_pos(U_comp' * A_L) + proj_neg(U_comp' * U_comp) * V;
    denom = proj_neg(U_comp' * A_L) + proj_pos(U_comp' * U_comp) * V + eps;
    V = ((num ./ denom) .^ 0.5) .* V;    
    V_comp = V * R;

    num = proj_pos(A_R * V_comp') + U * proj_neg(V_comp * V_comp');
    denom = proj_neg(A_R * V_comp') + U * proj_pos(V_comp * V_comp') + eps;
    U = U .* ((num ./ denom) .^ 0.5);
    U_comp = L * U;

    err(i) = log10(norm(M - U_comp * V_comp, 'fro'));

    if i > 1e1 && (err(i) < -5 || abs(err(i) - err(i-1)) <= 1e-5)
        err(i+1:end) = [];
        break;
    end
end

if issparse(A)
    U = sparse(U);
    V = sparse(V);
end
end

function B = proj_neg(A)
    B = (abs(A) - A) / 2;
end

function B = proj_pos(A)
    B = (abs(A) + A) / 2;
end
